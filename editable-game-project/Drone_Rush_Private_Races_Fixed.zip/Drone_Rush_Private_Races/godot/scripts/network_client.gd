extends Node
## Lightweight WebSocket JSON client, compatible with Godot's browser export.

signal message_received(data: Dictionary)
signal disconnected(reason: String)

var socket: WebSocketPeer = null
var queued_first_message: Dictionary = {}
var connected_once := false
var intentional_close := false


func connect_and_send(server_url: String, first_message: Dictionary) -> bool:
	close_connection()
	intentional_close = false
	connected_once = false
	queued_first_message = first_message
	socket = WebSocketPeer.new()
	var result := socket.connect_to_url(server_url)
	if result != OK:
		socket = null
		disconnected.emit("Couldn't start the WebSocket connection (%d)" % result)
		return false
	return true


func send_message(data: Dictionary) -> void:
	if socket != null and socket.get_ready_state() == WebSocketPeer.STATE_OPEN:
		socket.send_text(JSON.stringify(data))


func close_connection() -> void:
	intentional_close = true
	if socket != null:
		if socket.get_ready_state() == WebSocketPeer.STATE_OPEN:
			socket.close(1000, "Leaving")
		socket = null
	connected_once = false
	queued_first_message = {}


func _process(_delta: float) -> void:
	if socket == null:
		return
	socket.poll()
	var state := socket.get_ready_state()
	if state == WebSocketPeer.STATE_OPEN:
		if not connected_once:
			connected_once = true
			send_message(queued_first_message)
			queued_first_message = {}
		while socket != null and socket.get_available_packet_count() > 0:
			var packet := socket.get_packet().get_string_from_utf8()
			var data: Variant = JSON.parse_string(packet)
			if data is Dictionary:
				message_received.emit(data)
	elif state == WebSocketPeer.STATE_CLOSED:
		var reason := "Connection closed (code %d)" % socket.get_close_code()
		socket = null
		if not intentional_close:
			disconnected.emit(reason)
