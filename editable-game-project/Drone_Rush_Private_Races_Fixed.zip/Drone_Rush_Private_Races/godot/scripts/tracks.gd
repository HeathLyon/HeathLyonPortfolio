extends RefCounted
## Three hand-defined circuits. All tracks have eight ordered checkpoint gates.
## Change these arrays to design new layouts; graphics are generated at runtime.

const TRACKS := [
	{
		"name": "NEON CIRCUIT",
		"subtitle": "Fast city turns",
		"start": Vector3(0.0, 4.5, 5.0),
		"ground": Color(0.055, 0.09, 0.115),
		"sky": Color(0.025, 0.045, 0.085),
		"accent": Color(0.10, 0.93, 1.0),
		"gates": [
			Vector3(0.0, 4.5, -27.0), Vector3(0.0, 5.5, -54.0),
			Vector3(17.0, 6.5, -80.0), Vector3(45.0, 5.0, -84.0),
			Vector3(69.0, 4.5, -62.0), Vector3(70.0, 6.0, -29.0),
			Vector3(47.0, 7.0, -3.0), Vector3(21.0, 5.5, 6.0),
		]
	},
	{
		"name": "CANYON RUN",
		"subtitle": "Rock pillars and sweeping bends",
		"start": Vector3(0.0, 5.5, 15.0),
		"ground": Color(0.21, 0.11, 0.095),
		"sky": Color(0.14, 0.07, 0.085),
		"accent": Color(1.0, 0.60, 0.21),
		"gates": [
			Vector3(-5.0, 6.0, -18.0), Vector3(-27.0, 7.0, -46.0),
			Vector3(-52.0, 5.0, -67.0), Vector3(-43.0, 9.0, -100.0),
			Vector3(-6.0, 11.0, -113.0), Vector3(33.0, 7.0, -94.0),
			Vector3(39.0, 6.0, -45.0), Vector3(18.0, 6.0, -5.0),
		]
	},
	{
		"name": "SKY SPIRAL",
		"subtitle": "High-altitude climbing course",
		"start": Vector3(0.0, 7.0, 18.0),
		"ground": Color(0.065, 0.065, 0.13),
		"sky": Color(0.045, 0.03, 0.12),
		"accent": Color(0.75, 0.36, 1.0),
		"gates": [
			Vector3(0.0, 9.0, -16.0), Vector3(21.0, 14.0, -45.0),
			Vector3(56.0, 19.0, -42.0), Vector3(71.0, 22.0, -12.0),
			Vector3(54.0, 18.0, 20.0), Vector3(19.0, 14.0, 36.0),
			Vector3(-17.0, 10.0, 31.0), Vector3(-29.0, 8.0, 4.0),
		]
	},
]


static func get_track(index: int) -> Dictionary:
	return TRACKS[clampi(index, 0, TRACKS.size() - 1)]
