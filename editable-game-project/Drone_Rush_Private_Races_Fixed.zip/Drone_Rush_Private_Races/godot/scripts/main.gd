extends Node3D
## DRONE // RUSH: three procedural courses, single-player time trial, private rooms.
## Game remains mouse-only once a race begins. Network is JSON over WebSockets.

const TrackData = preload("res://scripts/tracks.gd")
const NetworkClient = preload("res://scripts/network_client.gd")

const TOTAL_LAPS := 2
const GATE_COUNT := 8
const GATE_RADIUS := 4.0
const CRUISE_SPEED := 14.0
const BOOST_SPEED := 25.0
const BRAKE_SPEED := 6.0
const TURN_RATE := 1.85
const CLIMB_RATE := 10.5
const TEAL := Color(0.10, 0.93, 1.0)
const GOLD := Color(1.0, 0.72, 0.22)
const PINK := Color(1.0, 0.19, 0.60)
const DIM_GATE := Color(0.20, 0.37, 0.43)

var track_index := 0
var stage: Node3D
var environment_node: WorldEnvironment
var drone: Node3D
var model: Node3D
var camera: Camera3D
var rotors: Array[Node3D] = []
var gate_mats: Array[StandardMaterial3D] = []
var remote_drones: Dictionary = {}
var remote_targets: Dictionary = {}
var network

var heading := 0.0
var current_speed := CRUISE_SPEED
var current_gate := 0
var current_lap := 1
var elapsed := 0.0
var running := false
var online := false
var countdown_active := false
var countdown_end_ticks := 0
var state_send_elapsed := 0.0
var best_times := [-1.0, -1.0, -1.0]
var own_id := ""
var host_id := ""
var room_code := ""
var lobby_players: Array = []
var last_result_players: Array = []
var menu_page := "main"
var status_text := ""
var incoming_join := false

var hud_left: Label
var hud_time: Label
var hud_next: Label
var hud_right: Label
var hud_help: Label
var hud_panel: PanelContainer
var exit_button: Button
var menu_overlay: ColorRect
var main_page: VBoxContainer
var lobby_page: VBoxContainer
var results_page: VBoxContainer
var player_name_edit: LineEdit
var relay_url_edit: LineEdit
var room_code_edit: LineEdit
var solo_track_select: OptionButton
var lobby_track_select: OptionButton
var main_status: Label
var lobby_title: Label
var lobby_roster: Label
var lobby_message: Label
var start_online_button: Button
var result_title: Label
var result_body: Label
var result_action_button: Button


func _ready() -> void:
	_build_environment()
	_build_local_drone()
	_build_camera()
	_load_track(0)
	_build_ui()
	_load_preferences()
	network = NetworkClient.new()
	add_child(network)
	network.message_received.connect(_on_message)
	network.disconnected.connect(_on_disconnect)
	_set_menu("main")
	_update_hud()


func _physics_process(delta: float) -> void:
	if not running:
		return
	var view_size := get_viewport().get_visible_rect().size
	var steer := Vector2.ZERO
	if view_size.x > 0.0 and view_size.y > 0.0:
		var mouse := get_viewport().get_mouse_position()
		steer.x = clampf((mouse.x / view_size.x - 0.5) * 2.35, -1.0, 1.0)
		steer.y = clampf((mouse.y / view_size.y - 0.5) * 2.35, -1.0, 1.0)

	heading -= steer.x * TURN_RATE * delta
	drone.rotation.y = heading
	var forward := -drone.global_transform.basis.z
	var target_speed := CRUISE_SPEED
	if Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
		target_speed = BRAKE_SPEED
	elif Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		target_speed = BOOST_SPEED
	current_speed = move_toward(current_speed, target_speed, 24.0 * delta)

	var old_position := drone.global_position
	drone.global_position += forward * current_speed * delta
	drone.global_position.y = clampf(drone.global_position.y - steer.y * CLIMB_RATE * delta, 1.25, 26.0)
	model.rotation.z = lerpf(model.rotation.z, -steer.x * 0.46, minf(1.0, delta * 5.0))
	model.rotation.x = lerpf(model.rotation.x, -0.12 - steer.y * 0.20, minf(1.0, delta * 5.0))
	elapsed += delta
	_check_gate(old_position, drone.global_position)

	if online:
		state_send_elapsed += delta
		if state_send_elapsed >= 0.08:
			state_send_elapsed = 0.0
			network.send_message({
				"type": "state",
				"p": [drone.global_position.x, drone.global_position.y, drone.global_position.z],
				"yaw": heading,
			})


func _process(delta: float) -> void:
	for rotor in rotors:
		rotor.rotation.y += delta * (30.0 + current_speed)
	if drone != null and camera != null:
		var forward := -drone.global_transform.basis.z
		var desired := drone.global_position - forward * 9.5 + Vector3.UP * 4.1
		camera.global_position = camera.global_position.lerp(desired, minf(1.0, delta * 4.8))
		camera.look_at(drone.global_position + forward * 8.0 + Vector3.UP * 0.7, Vector3.UP)
	for id in remote_drones.keys():
		if not remote_targets.has(id):
			continue
		var other: Node3D = remote_drones[id]
		var target: Dictionary = remote_targets[id]
		other.global_position = other.global_position.lerp(target["position"], minf(1.0, delta * 11.0))
		other.rotation.y = lerp_angle(other.rotation.y, float(target["yaw"]), minf(1.0, delta * 11.0))

	if countdown_active:
		var left_ms := maxi(0, countdown_end_ticks - Time.get_ticks_msec())
		lobby_message.text = "RACE STARTS IN  %d" % maxi(1, ceili(float(left_ms) / 1000.0))
	if running:
		_update_hud()


func _build_environment() -> void:
	environment_node = WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.025, 0.045, 0.085)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.56, 0.66, 0.9)
	env.ambient_light_energy = 0.95
	environment_node.environment = env
	add_child(environment_node)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-58.0, -25.0, 0.0)
	sun.light_energy = 0.9
	sun.light_color = Color(0.70, 0.83, 1.0)
	add_child(sun)


func _load_track(new_index: int) -> void:
	track_index = clampi(new_index, 0, 2)
	if stage != null:
		remove_child(stage)
		stage.queue_free()
	gate_mats.clear()
	stage = Node3D.new()
	stage.name = "Track"
	add_child(stage)
	var track := TrackData.get_track(track_index)
	environment_node.environment.background_color = track["sky"]
	var ground := MeshInstance3D.new()
	var plane := PlaneMesh.new()
	plane.size = Vector2(420.0, 420.0)
	ground.mesh = plane
	ground.position = Vector3(15.0, -0.15, -35.0)
	ground.material_override = _material(track["ground"], false)
	stage.add_child(ground)
	var grid_mat := _material(Color(0.12, 0.22, 0.26) if track_index == 0 else track["accent"].darkened(0.75), true)
	for n in range(-13, 14):
		_box(stage, Vector3(420.0, 0.025, 0.052), Vector3(15.0, -0.09, float(n) * 13.0 - 35.0), grid_mat)
		_box(stage, Vector3(0.052, 0.025, 420.0), Vector3(float(n) * 13.0 + 15.0, -0.08, -35.0), grid_mat)

	var gates: Array = track["gates"]
	for i in range(gates.size()):
		var gate := Node3D.new()
		gate.name = "Gate_%02d" % (i + 1)
		stage.add_child(gate)
		gate.position = gates[i]
		var prev: Vector3 = track["start"] if i == 0 else gates[i - 1]
		var following: Vector3 = gates[(i + 1) % gates.size()]
		var direction := following - prev
		direction.y = 0.0
		if direction.length_squared() > 0.001:
			gate.look_at(gate.global_position + direction.normalized(), Vector3.UP)
		var gate_mat := _material(DIM_GATE, true)
		gate_mats.append(gate_mat)
		_box(gate, Vector3(0.35, 7.6, 0.4), Vector3(-4.1, 0, 0), gate_mat)
		_box(gate, Vector3(0.35, 7.6, 0.4), Vector3(4.1, 0, 0), gate_mat)
		_box(gate, Vector3(8.5, 0.35, 0.4), Vector3(0, 3.8, 0), gate_mat)
		_box(gate, Vector3(8.5, 0.2, 0.4), Vector3(0, -3.8, 0), gate_mat)
		if track_index != 2:
			var leg_height: float = maxf(0.3, float(gates[i].y) - 3.8)
			var leg_mat := _material(track["ground"].lightened(0.14), false)
			for side in [-4.1, 4.1]:
				var local_leg := Vector3(float(side), -3.8 - leg_height / 2.0, 0)
				_box(gate, Vector3(0.28, leg_height, 0.28), local_leg, leg_mat)

	_build_track_scenery(gates, track)
	_highlight_gate()
	if drone != null:
		_reset_drone()
	for id in remote_drones.keys():
		var remote: Node3D = remote_drones[id]
		remote.global_position = track["start"] + Vector3(0, 0, 3)


func _build_track_scenery(gates: Array, track: Dictionary) -> void:
	var highlight := _material(track["accent"], true)
	var rock := _material(Color(0.36, 0.19, 0.14), false)
	var city := _material(Color(0.12, 0.22, 0.30), false)
	var sky_metal := _material(Color(0.20, 0.18, 0.39), false)
	for i in range(gates.size()):
		var point: Vector3 = gates[i]
		for side in [-1.0, 1.0]:
			var offset: float = float(side) * (24.0 + float(i % 3) * 6.0)
			var h := 7.0 + float((i * 11 + (1 if side > 0 else 6)) % 17)
			if track_index == 0:
				_box(stage, Vector3(4, h, 4), Vector3(point.x + offset, h / 2.0, point.z + 5.0), city)
				_box(stage, Vector3(4.2, 0.26, 4.2), Vector3(point.x + offset, h + 0.1, point.z + 5.0), highlight)
			elif track_index == 1:
				_box(stage, Vector3(8, h, 8), Vector3(point.x + offset, h / 2.0, point.z + 4.0), rock)
				_box(stage, Vector3(5, 3, 5), Vector3(point.x + offset, h + 1.5, point.z + 4.0), rock)
			else:
				var height := 10.0 + float(i * 3)
				_box(stage, Vector3(5, height, 5), Vector3(point.x + offset, height / 2.0, point.z), sky_metal)
				_box(stage, Vector3(5.5, 0.24, 5.5), Vector3(point.x + offset, height, point.z), highlight)


func _build_local_drone() -> void:
	drone = Node3D.new()
	drone.name = "LocalDrone"
	add_child(drone)
	model = _construct_drone_model(drone, TEAL, true)


func _construct_drone_model(parent: Node3D, accent: Color, is_local: bool) -> Node3D:
	var body := Node3D.new()
	body.name = "QuadcopterModel"
	parent.add_child(body)
	var shell := _material(Color(0.12, 0.16, 0.23), false)
	var frame := _material(Color(0.18, 0.24, 0.29), false)
	var bright := _material(accent, true)
	var tail := _material(PINK, true)
	_box(body, Vector3(0.92, 0.30, 1.25), Vector3.ZERO, shell)
	_box(body, Vector3(1.1, 0.14, 0.18), Vector3(0, 0.1, -0.25), bright)
	_box(body, Vector3(0.8, 0.12, 0.16), Vector3(0, 0.05, 0.55), tail)
	_box(body, Vector3(2.65, 0.10, 0.12), Vector3(0, 0.02, 0), frame)
	_box(body, Vector3(0.12, 0.10, 2.65), Vector3(0, 0.02, 0), frame)
	for x in [-1.28, 1.28]:
		for z in [-1.28, 1.28]:
			var motor := Node3D.new()
			motor.position = Vector3(x, 0.12, z)
			body.add_child(motor)
			_box(motor, Vector3(0.27, 0.20, 0.27), Vector3.ZERO, shell)
			var prop := Node3D.new()
			prop.position.y = 0.16
			motor.add_child(prop)
			_box(prop, Vector3(1.07, 0.025, 0.095), Vector3.ZERO, bright)
			_box(prop, Vector3(0.095, 0.025, 1.07), Vector3.ZERO, bright)
			if is_local:
				rotors.append(prop)
	return body


func _build_camera() -> void:
	camera = Camera3D.new()
	camera.name = "ChaseCamera"
	camera.fov = 83.0
	camera.near = 0.08
	camera.far = 440.0
	add_child(camera)
	camera.current = true


func _reset_drone() -> void:
	var origin: Vector3 = TrackData.get_track(track_index)["start"]
	if online and own_id != "":
		var order := 0
		for i in range(lobby_players.size()):
			if str(lobby_players[i].get("id", "")) == own_id:
				order = i
		var offset := float(order) * 2.4
		origin += Vector3(offset, 0.0, offset)
	drone.global_position = origin
	drone.rotation = Vector3.ZERO
	model.rotation = Vector3.ZERO
	heading = 0.0
	current_speed = CRUISE_SPEED
	if camera != null:
		camera.global_position = origin + Vector3(0, 4.1, 9.5)
		camera.look_at(origin + Vector3(0, 0, -8), Vector3.UP)


func _build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(root)

	hud_panel = PanelContainer.new()
	hud_panel.position = Vector2(22, 20)
	hud_panel.custom_minimum_size = Vector2(330, 135)
	hud_panel.add_theme_stylebox_override("panel", _panel_style(Color(0.025, 0.045, 0.075, 0.87)))
	root.add_child(hud_panel)
	var hud_stack := VBoxContainer.new()
	hud_stack.add_theme_constant_override("separation", 5)
	hud_panel.add_child(hud_stack)
	hud_left = _label("LAP 1 / 2  •  GATE 1 / 8", 19, TEAL)
	hud_time = _label("00:00.00", 30, Color.WHITE)
	hud_next = _label("NEXT GATE", 15, Color(0.80, 0.90, 0.96))
	hud_stack.add_child(hud_left)
	hud_stack.add_child(hud_time)
	hud_stack.add_child(hud_next)

	hud_right = _label("", 17, GOLD)
	hud_right.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	hud_right.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	hud_right.offset_left = -290.0
	hud_right.offset_right = -24.0
	hud_right.offset_top = 52.0
	hud_right.offset_bottom = 137.0
	root.add_child(hud_right)

	hud_help = _label("MOVE MOUSE: STEER / CLIMB    •    HOLD LEFT: BOOST    •    HOLD RIGHT: BRAKE", 16, Color(0.85, 0.94, 1.0))
	hud_help.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hud_help.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	hud_help.offset_top = -45.0
	hud_help.offset_bottom = -15.0
	root.add_child(hud_help)

	exit_button = _button("LEAVE RACE", _leave_session)
	exit_button.custom_minimum_size = Vector2(130, 36)
	exit_button.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	exit_button.offset_left = -152.0
	exit_button.offset_right = -22.0
	exit_button.offset_top = 9.0
	exit_button.offset_bottom = 45.0
	root.add_child(exit_button)

	menu_overlay = ColorRect.new()
	menu_overlay.color = Color(0.017, 0.029, 0.052, 0.93)
	menu_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	menu_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	root.add_child(menu_overlay)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	menu_overlay.add_child(center)
	var card := PanelContainer.new()
	card.custom_minimum_size = Vector2(575, 0)
	card.add_theme_stylebox_override("panel", _panel_style(Color(0.065, 0.10, 0.16, 0.98)))
	center.add_child(card)
	var all_pages := VBoxContainer.new()
	all_pages.add_theme_constant_override("separation", 9)
	card.add_child(all_pages)
	var title := _label("DRONE // RUSH", 40, TEAL)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	all_pages.add_child(title)

	main_page = VBoxContainer.new()
	main_page.add_theme_constant_override("separation", 9)
	all_pages.add_child(main_page)
	var intro := _label("3 TRACKS   •   SINGLE PLAYER   •   PRIVATE ONLINE RACES", 16, Color(0.84, 0.89, 0.98))
	intro.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	main_page.add_child(intro)
	player_name_edit = _make_line_edit("Pilot name", "Pilot", 18)
	main_page.add_child(_label("PILOT NAME", 13, TEAL))
	main_page.add_child(player_name_edit)
	solo_track_select = _track_selector()
	main_page.add_child(_label("TRACK", 13, TEAL))
	main_page.add_child(solo_track_select)
	main_page.add_child(_button("SOLO TIME TRIAL", _start_solo))
	main_page.add_child(HSeparator.new())
	main_page.add_child(_label("MULTIPLAYER SERVER (WSS URL for public websites)", 13, TEAL))
	relay_url_edit = _make_line_edit("wss://your-server.example/ws", "", 230)
	main_page.add_child(relay_url_edit)
	var online_buttons := HBoxContainer.new()
	main_page.add_child(online_buttons)
	var host_btn := _button("HOST PRIVATE RACE", _host_race)
	host_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	online_buttons.add_child(host_btn)
	room_code_edit = _make_line_edit("6-CHAR CODE", "", 6)
	room_code_edit.custom_minimum_size.x = 155.0
	online_buttons.add_child(room_code_edit)
	var join_btn := _button("JOIN", _join_race)
	online_buttons.add_child(join_btn)
	main_status = _label("", 14, GOLD)
	main_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	main_page.add_child(main_status)

	lobby_page = VBoxContainer.new()
	lobby_page.add_theme_constant_override("separation", 12)
	all_pages.add_child(lobby_page)
	lobby_title = _label("PRIVATE ROOM", 27, GOLD)
	lobby_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	lobby_page.add_child(lobby_title)
	lobby_page.add_child(_label("Share the room code with friends on the same relay server.", 15, Color.WHITE))
	lobby_page.add_child(_label("RACE TRACK", 13, TEAL))
	lobby_track_select = _track_selector()
	lobby_track_select.item_selected.connect(_on_host_track_changed)
	lobby_page.add_child(lobby_track_select)
	lobby_roster = _label("Waiting for pilots...", 18, Color(0.87, 0.94, 1.0))
	lobby_page.add_child(lobby_roster)
	lobby_message = _label("", 18, GOLD)
	lobby_page.add_child(lobby_message)
	start_online_button = _button("START RACE", _host_start_race)
	lobby_page.add_child(start_online_button)
	lobby_page.add_child(_button("LEAVE ROOM", _leave_session))

	results_page = VBoxContainer.new()
	results_page.add_theme_constant_override("separation", 12)
	all_pages.add_child(results_page)
	result_title = _label("FINISH LINE!", 32, GOLD)
	result_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	results_page.add_child(result_title)
	result_body = _label("", 18, Color(0.89, 0.95, 1.0))
	result_body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	results_page.add_child(result_body)
	result_action_button = _button("RACE AGAIN", _results_action)
	results_page.add_child(result_action_button)
	results_page.add_child(_button("MAIN MENU / LEAVE", _leave_session))


func _set_menu(page: String) -> void:
	menu_page = page
	menu_overlay.visible = page != "race"
	main_page.visible = page == "main"
	lobby_page.visible = page == "lobby" or page == "countdown"
	results_page.visible = page == "results"
	hud_panel.visible = page == "race"
	hud_right.visible = page == "race"
	hud_help.visible = page == "race"
	exit_button.visible = page == "race"


func _start_solo() -> void:
	_leave_network_only()
	online = false
	_load_track(solo_track_select.selected)
	_begin_flight()


func _begin_flight() -> void:
	countdown_active = false
	current_gate = 0
	current_lap = 1
	elapsed = 0.0
	state_send_elapsed = 0.0
	_reset_drone()
	_highlight_gate()
	running = true
	_set_menu("race")
	_update_hud()


func _host_race() -> void:
	_start_connection({"type": "create", "name": _pilot_name(), "track": solo_track_select.selected})


func _join_race() -> void:
	var code := room_code_edit.text.strip_edges().to_upper()
	if code.length() != 6:
		main_status.text = "Enter the six-character room code."
		return
	_start_connection({"type": "join", "name": _pilot_name(), "code": code})


func _start_connection(first_message: Dictionary) -> void:
	var url := relay_url_edit.text.strip_edges()
	if not (url.begins_with("ws://") or url.begins_with("wss://")):
		main_status.text = "Enter a WebSocket server URL (ws:// or wss://)."
		return
	if OS.has_feature("web") and url.begins_with("ws://") and not (url.contains("localhost") or url.contains("127.0.0.1")):
		main_status.text = "A public HTTPS site requires a secure wss:// server URL."
		return
	_leave_network_only()
	online = true
	incoming_join = true
	main_status.text = "Connecting to relay..."
	_save_preferences()
	if not network.connect_and_send(url, first_message):
		incoming_join = false


func _host_start_race() -> void:
	if own_id != host_id or lobby_players.size() < 2:
		return
	network.send_message({"type": "start"})
	lobby_message.text = "Starting race..."


func _on_host_track_changed(index: int) -> void:
	if own_id == host_id and not countdown_active and lobby_page.visible:
		network.send_message({"type": "set_track", "track": index})


func _on_message(message: Dictionary) -> void:
	var kind := str(message.get("type", ""))
	match kind:
		"joined":
			own_id = str(message.get("player_id", ""))
			incoming_join = false
		"room":
			room_code = str(message.get("code", ""))
			host_id = str(message.get("host_id", ""))
			lobby_players = message.get("players", [])
			var new_track := int(message.get("track", 0))
			if new_track != track_index:
				_load_track(new_track)
			_refresh_lobby()
			_sync_remote_drones()
			if str(message.get("phase", "lobby")) == "lobby":
				running = false
				countdown_active = false
				_set_menu("lobby")
		"countdown":
			_load_track(int(message.get("track", 0)))
			_sync_remote_drones()
			remote_targets.clear()
			for id in remote_drones.keys():
				var opponent: Node3D = remote_drones[id]
				opponent.global_position = TrackData.get_track(track_index)["start"] + Vector3(3.0, 0.0, 3.0)
			running = false
			countdown_active = true
			var remaining_ms := int(message.get("start_at_ms", 0)) - int(message.get("server_now_ms", 0))
			countdown_end_ticks = Time.get_ticks_msec() + maxi(0, remaining_ms)
			lobby_message.text = "RACE STARTS IN 3"
			_set_menu("countdown")
		"go":
			if countdown_active:
				_begin_flight()
		"state":
			_receive_drone_state(message)
		"progress":
			_update_opponent_progress(message)
		"race_over":
			running = false
			countdown_active = false
			last_result_players = message.get("results", [])
			_show_results(bool(message.get("timeout", false)))
		"left":
			_remove_remote(str(message.get("id", "")))
		"error":
			var detail := str(message.get("message", "Unknown error"))
			if menu_page == "main":
				main_status.text = detail
			else:
				lobby_message.text = detail


func _on_disconnect(reason: String) -> void:
	if not online:
		return
	_leave_network_only()
	running = false
	countdown_active = false
	_set_menu("main")
	main_status.text = "Disconnected: " + reason


func _refresh_lobby() -> void:
	lobby_title.text = "ROOM  " + room_code
	lobby_track_select.selected = track_index
	lobby_track_select.disabled = own_id != host_id
	var roster := "PILOTS  %d / 6\n" % lobby_players.size()
	for p in lobby_players:
		var mark := "  [HOST]" if str(p.get("id", "")) == host_id else ""
		roster += "  •  %s%s\n" % [str(p.get("name", "Pilot")), mark]
	lobby_roster.text = roster
	start_online_button.visible = own_id == host_id
	start_online_button.disabled = lobby_players.size() < 2
	if not countdown_active:
		lobby_message.text = "Waiting for one more pilot..." if lobby_players.size() < 2 else ("Choose a track and start when ready." if own_id == host_id else "Waiting for host to start...")


func _sync_remote_drones() -> void:
	if not online:
		return
	var active_ids: Array[String] = []
	for p in lobby_players:
		var id := str(p.get("id", ""))
		if id == "" or id == own_id:
			continue
		active_ids.append(id)
		if not remote_drones.has(id):
			var remote := Node3D.new()
			remote.name = "RemoteDrone_" + id
			add_child(remote)
			var tint := Color(1.0, 0.55, 0.18) if active_ids.size() % 2 == 1 else Color(0.80, 0.39, 1.0)
			_construct_drone_model(remote, tint, false)
			remote.global_position = TrackData.get_track(track_index)["start"] + Vector3(3.0 * active_ids.size(), 0, 3.0)
			remote_drones[id] = remote
	for id in remote_drones.keys():
		if not active_ids.has(id):
			_remove_remote(id)


func _remove_remote(id: String) -> void:
	if remote_drones.has(id):
		var remote: Node3D = remote_drones[id]
		remote.queue_free()
		remote_drones.erase(id)
	remote_targets.erase(id)


func _receive_drone_state(data: Dictionary) -> void:
	var id := str(data.get("id", ""))
	if id == own_id or not remote_drones.has(id):
		return
	var p: Array = data.get("p", [])
	if p.size() != 3:
		return
	remote_targets[id] = {
		"position": Vector3(float(p[0]), float(p[1]), float(p[2])),
		"yaw": float(data.get("yaw", 0.0))
	}


func _update_opponent_progress(data: Dictionary) -> void:
	for p in lobby_players:
		if str(p.get("id", "")) == str(data.get("id", "")):
			p["passed"] = int(data.get("passed", 0))
			p["finished_ms"] = data.get("finished_ms", null)
			break


func _check_gate(previous: Vector3, current: Vector3) -> void:
	var gates: Array = TrackData.get_track(track_index)["gates"]
	var center: Vector3 = gates[current_gate]
	var movement := current - previous
	var t := 0.0
	var squared := movement.length_squared()
	if squared > 0.0001:
		t = clampf((center - previous).dot(movement) / squared, 0.0, 1.0)
	if (previous + movement * t).distance_to(center) > GATE_RADIUS:
		return
	current_gate += 1
	var completed := (current_lap - 1) * GATE_COUNT + current_gate
	if online:
		network.send_message({"type": "gate", "passed": completed})
	if current_gate >= GATE_COUNT:
		current_gate = 0
		current_lap += 1
		if current_lap > TOTAL_LAPS:
			_finish_local_race()
			return
	_highlight_gate()
	_update_hud()


func _finish_local_race() -> void:
	running = false
	if online:
		result_title.text = "FINISHED!"
		result_body.text = "Your time: %s\n\nWaiting for the other pilots to finish..." % _time_string(elapsed)
		result_action_button.visible = false
		_set_menu("results")
	else:
		var old_best := float(best_times[track_index])
		var new_best := old_best < 0.0 or elapsed < old_best
		if new_best:
			best_times[track_index] = elapsed
			_save_records()
		result_title.text = "NEW PERSONAL BEST!" if new_best else "FINISH LINE!"
		result_body.text = "%s\nTwo laps: %s\nPersonal best: %s" % [str(TrackData.get_track(track_index)["name"]), _time_string(elapsed), _time_string(float(best_times[track_index]))]
		result_action_button.text = "RACE AGAIN"
		result_action_button.visible = true
		_set_menu("results")


func _show_results(timed_out: bool) -> void:
	result_title.text = "RACE RESULTS" if not timed_out else "TIME LIMIT REACHED"
	var output := "%s\n" % str(TrackData.get_track(track_index)["name"])
	for i in range(last_result_players.size()):
		var p: Dictionary = last_result_players[i]
		var final_ms: Variant = p.get("finished_ms", null)
		var time_text := "DNF (%d gates)" % int(p.get("passed", 0))
		if final_ms != null:
			time_text = _time_string(float(final_ms) / 1000.0)
		var self_marker := "  (YOU)" if str(p.get("id", "")) == own_id else ""
		output += "%d.  %s%s  —  %s\n" % [i + 1, str(p.get("name", "Pilot")), self_marker, time_text]
	result_body.text = output
	result_action_button.text = "RETURN TO LOBBY"
	result_action_button.visible = own_id == host_id
	_set_menu("results")


func _results_action() -> void:
	if online:
		if own_id == host_id:
			network.send_message({"type": "reset"})
	else:
		_begin_flight()


func _leave_session() -> void:
	running = false
	countdown_active = false
	_leave_network_only()
	_set_menu("main")
	main_status.text = ""


func _leave_network_only() -> void:
	if network != null:
		network.close_connection()
	for id in remote_drones.keys():
		_remove_remote(id)
	online = false
	incoming_join = false
	own_id = ""
	host_id = ""
	room_code = ""
	lobby_players.clear()


func _highlight_gate() -> void:
	for i in range(gate_mats.size()):
		var color: Color = GOLD if i == current_gate else DIM_GATE
		gate_mats[i].albedo_color = color
		gate_mats[i].emission = color


func _update_hud() -> void:
	if hud_left == null:
		return
	hud_left.text = "%s\nLAP %d / %d  •  GATE %d / %d" % [str(TrackData.get_track(track_index)["name"]), mini(current_lap, TOTAL_LAPS), TOTAL_LAPS, current_gate + 1, GATE_COUNT]
	hud_time.text = _time_string(elapsed)
	var gates: Array = TrackData.get_track(track_index)["gates"]
	var target: Vector3 = gates[current_gate]
	var distance := drone.global_position.distance_to(target)
	var flat := target - drone.global_position
	flat.y = 0.0
	var hint := "AHEAD"
	if flat.length() > 0.1:
		var side := flat.normalized().dot(drone.global_transform.basis.x)
		if side > 0.28:
			hint = "TURN RIGHT"
		elif side < -0.28:
			hint = "TURN LEFT"
	hud_next.text = "GATE %02d  •  %d m  •  %s" % [current_gate + 1, roundi(distance), hint]
	var record := "--:--.--" if float(best_times[track_index]) < 0 else _time_string(float(best_times[track_index]))
	var score := "BEST  " + record
	if online:
		var sorted_players := lobby_players.duplicate(true)
		sorted_players.sort_custom(func(a, b): return int(a.get("passed", 0)) > int(b.get("passed", 0)))
		var rank := 1
		for p in sorted_players:
			if str(p.get("id", "")) == own_id:
				break
			rank += 1
		score = "POSITION  %d / %d" % [rank, maxi(1, lobby_players.size())]
	hud_right.text = "SPEED  %d km/h\nALT  %.1f m\n%s" % [roundi(current_speed * 3.6), drone.global_position.y, score]


func _pilot_name() -> String:
	var name := player_name_edit.text.strip_edges()
	return "Pilot" if name.is_empty() else name.substr(0, 18)


func _load_preferences() -> void:
	var config := ConfigFile.new()
	if config.load("user://drone_rush_prefs.cfg") == OK:
		player_name_edit.text = str(config.get_value("profile", "name", "Pilot"))
		relay_url_edit.text = str(config.get_value("profile", "relay_url", ""))
	else:
		player_name_edit.text = "Pilot"
		relay_url_edit.text = "" if OS.has_feature("web") else "ws://127.0.0.1:8765/ws"
	if OS.has_feature("web"):
		var query_value: Variant = JavaScriptBridge.eval("new URLSearchParams(window.location.search).get('relay') || ''", true)
		if query_value is String and not query_value.is_empty():
			relay_url_edit.text = query_value
	var records := ConfigFile.new()
	if records.load("user://drone_rush_records.cfg") == OK:
		for i in range(3):
			best_times[i] = float(records.get_value("records", "track_%d" % i, -1.0))


func _save_preferences() -> void:
	var config := ConfigFile.new()
	config.set_value("profile", "name", _pilot_name())
	config.set_value("profile", "relay_url", relay_url_edit.text.strip_edges())
	config.save("user://drone_rush_prefs.cfg")


func _save_records() -> void:
	var config := ConfigFile.new()
	for i in range(3):
		config.set_value("records", "track_%d" % i, best_times[i])
	config.save("user://drone_rush_records.cfg")


func _time_string(seconds: float) -> String:
	var centiseconds := maxi(0, roundi(seconds * 100.0))
	var minutes := centiseconds / 6000
	var remaining := (centiseconds / 100) % 60
	var cents := centiseconds % 100
	return "%02d:%02d.%02d" % [minutes, remaining, cents]


func _track_selector() -> OptionButton:
	var choice := OptionButton.new()
	for track in TrackData.TRACKS:
		choice.add_item(str(track["name"]) + "  —  " + str(track["subtitle"]))
	choice.selected = 0
	choice.custom_minimum_size.y = 38
	return choice


func _make_line_edit(hint: String, initial: String, max_chars: int) -> LineEdit:
	var edit := LineEdit.new()
	edit.placeholder_text = hint
	edit.text = initial
	edit.max_length = max_chars
	edit.custom_minimum_size.y = 39
	return edit


func _button(title: String, handler: Callable) -> Button:
	var button := Button.new()
	button.text = title
	button.custom_minimum_size.y = 41
	button.add_theme_font_size_override("font_size", 17)
	button.add_theme_color_override("font_color", Color(0.05, 0.09, 0.13))
	button.add_theme_stylebox_override("normal", _panel_style(TEAL))
	button.add_theme_stylebox_override("hover", _panel_style(Color(0.55, 1.0, 1.0)))
	button.add_theme_stylebox_override("pressed", _panel_style(GOLD))
	button.pressed.connect(handler)
	return button


func _material(color: Color, glowing: bool) -> StandardMaterial3D:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = 0.48
	mat.metallic = 0.1
	if glowing:
		mat.emission_enabled = true
		mat.emission = color
		mat.emission_energy_multiplier = 2.0
	return mat


func _box(parent: Node3D, size: Vector3, at: Vector3, material: Material) -> MeshInstance3D:
	var item := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	item.mesh = mesh
	item.material_override = material
	item.position = at
	parent.add_child(item)
	return item


func _label(value: String, font_size: int, color: Color) -> Label:
	var label := Label.new()
	label.text = value
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", color)
	return label


func _panel_style(fill: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = fill
	style.corner_radius_top_left = 10
	style.corner_radius_top_right = 10
	style.corner_radius_bottom_left = 10
	style.corner_radius_bottom_right = 10
	style.content_margin_left = 15
	style.content_margin_right = 15
	style.content_margin_top = 10
	style.content_margin_bottom = 10
	return style
