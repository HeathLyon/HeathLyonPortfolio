# DRONE // RUSH — Three-Track Private Multiplayer Edition

A Godot 4.7.x GDScript prototype with **three racing tracks**, a **solo time trial**, and **private browser-compatible room-code multiplayer**.

## Contents

```
Drone_Rush_Private_Races/
  godot/                 Godot project (open project.godot)
  server/                Python aiohttp WebSocket lobby/race relay
  site/drone-rush.html   Website launch page; iframe points to exported Godot build
  README.md              This guide
```

## Features implemented

- Three different tracks: **Neon Circuit**, **Canyon Run**, **Sky Spiral**.
- 2 laps × 8 gates, boost/brake mouse controls unchanged.
- Solo best time saved **separately per track** in `user://`.
- Host creates a 6-character private room code, chooses a track, starts the race (2–6 players).
- Another player enters the code and joins the same room.
- Relay sends 3.5-second countdown then `go`; other drones interpolated from 12.5 Hz position updates.
- Checkpoint progression and finish order relayed through server; room host may return players to lobby after all finish or the 8-minute limit.
- Host transfers automatically if host disconnects. Room is deleted when the last player leaves.
- Compatible with browser exports using Godot **Compatibility** renderer and WebSockets.

## Quick local multiplayer test

1. Install Python 3.11+, and from `server/` run:

   ```bash
   python -m pip install -r requirements.txt
   python server.py
   ```

   The server is listening at `ws://127.0.0.1:8765/ws`; health check: `http://127.0.0.1:8765/health`.

2. Install **Godot 4.7.2 stable, standard build** (non-.NET), import `godot/project.godot`.
3. Run the project in **two Godot windows** (Project > Run Multiple Instances) or open a second copy of the project. In both, enter `ws://127.0.0.1:8765/ws` as the server URL.
4. Window A: enter pilot name, select a track, click **HOST PRIVATE RACE**; read the 6-character room code.
5. Window B: enter a pilot name, type that room code, press **JOIN**. The host presses **START RACE**.
6. Confirm both windows show the other drone, gate progress, and results. Solo races work without a server.

To run server tests:

```bash
cd server
python -m unittest test_server.py -v
```

## Deploy relay (required for multiplayer on the public internet)

GitHub Pages **cannot host the WebSocket server**. Deploy `server/` on a Python-compatible cloud platform such as Render, Railway, or a VPS. A sample repository-root `render.yaml` Blueprint is provided.

- Server start command: `python server.py`
- Required server `PORT` comes from host environment (defaults to 8765 locally).
- Health endpoint: `/health`
- WebSocket endpoint: `/ws`
- Set `ALLOWED_ORIGINS` to the origins you actually use, e.g. `https://heathfpv.com,https://html-classic.itch.zone` (or `*` only for local testing); for itch.io, inspect the actual WebSocket Origin header as the embedded game may run on an itch-zone origin, not the visible itch.io page. Add both `https://www.heathfpv.com` and `https://heathfpv.com` if you use both.
- Make sure hosting supports **WebSockets** and **wss://** (HTTPS-backed TLS), and does not spin down between multiplayer matches. Providers' plans and policies change.
- A hosted WebSocket URL will typically resemble `wss://YOUR-RELAY-HOST/ws`. Verify it in a browser or with a WebSocket client before publishing.

This server intentionally keeps matches in memory: restarting it ends all rooms. It is suitable for a casual prototype, **not production anti-cheat**. Positions are accepted from clients; gate order and finishing timestamps are tracked by the server.

## Export Godot for GitHub Pages and itch.io

> The **source project is included**, but a generated `.wasm` web binary is **not bundled**. Export in Godot with the matching export templates installed; do not upload this source ZIP as the HTML5 game.

1. Open `godot/project.godot` in Godot 4.7.2.
2. Editor > Manage Export Templates: install the matching templates.
3. Project > Export > Add… > **Web**. Keep **Thread Support disabled** and **Extensions Support disabled**. Compatibility renderer is already set.
4. Export Project to an empty directory as `index.html`.
5. For your existing GitHub Pages repo, put **all exported files** together at `games/drone-rush/` in the repo root; the generated `index.html` must be at `games/drone-rush/index.html`.
6. Copy `site/drone-rush.html` into the website repo root as `drone-rush.html`.
7. In that HTML file edit the single `const RELAY_URL = "";` line to your deployed `wss://.../ws` URL. The landing page automatically passes it to the Godot game, so visitors don't need to type it.
8. Add a link to `/drone-rush.html` in the site's main navigation. **Do not replace your current portfolio homepage.**
9. Commit and push to the branch your GitHub Pages website uses. After Pages deploys, visit `/drone-rush.html` on a desktop browser and test with 2 players in separate devices/browsers.

For itch.io: ZIP **the contents** of the exported folder with `index.html` at ZIP root, then upload as an **HTML game**, allow browser play and fullscreen. On itch.io, you can pass the relay URL by editing `godot/scripts/main.gd` in `_load_preferences()` to default to your deployed `wss://.../ws` address before exporting. Alternatively the player can enter the server URL manually in the UI. The two copies can play together as long as both connect to the same server.

The iframe assumes the hosting repo is deployed at **your domain root**. If GitHub Pages is served under a subpath, adjust its `src` and the `new URL(...)` path in the landing page.

## Where to edit later

- Race course gates, colors and start positions: `godot/scripts/tracks.gd` (the `TRACKS` list).
- Drone speed, mouse sensitivity, checkpoint radius, UI: `godot/scripts/main.gd`.
- Room size, gates per race, race time limit and server policy: `server/server.py`.
- Website appearance: `site/drone-rush.html`.

## Known MVP limits

- No collision, crash damage, power-ups, chat, authentication or matchmaking.
- Flight movement is client-side; the relay only verifies gate sequence, not physical gate intersections. This is intended for private friends' races.
- Remote drones are interpolated; high latency may show jitter or delay. WebSockets use TCP, not real-time UDP.
- Room codes only work on the **same relay server**; hosting must remain awake during races.
- Mobile touch flight controls are **not implemented**; play with a mouse on desktop/laptop.
- The Godot project **has not been engine-validated in this environment**. Run both native and HTML5 tests before announcing the game as live.

Official docs: https://docs.godotengine.org/en/stable/tutorials/export/exporting_for_web.html and https://docs.godotengine.org/en/stable/tutorials/networking/websocket.html
