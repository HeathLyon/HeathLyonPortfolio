# Run on Windows after installing Godot 4.7.2 and its Web export templates.
# Examples:
#   .\\scripts\\export-web.ps1
#   .\\scripts\\export-web.ps1 -GodotPath 'C:\\Tools\\Godot_v4.7.2-stable_win64_console.exe'
param([string]$GodotPath = 'godot')
$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$project = Join-Path $root 'godot'
$target = Join-Path $root 'site\games\drone-rush'
New-Item -ItemType Directory -Force -Path $target | Out-Null
& $GodotPath --headless --path $project --editor --quit
if ($LASTEXITCODE -ne 0) { throw 'Godot project import failed.' }
& $GodotPath --headless --path $project --export-release 'Web' (Join-Path $target 'index.html')
if ($LASTEXITCODE -ne 0) { throw 'Godot Web export failed. Check installed matching export templates.' }
Write-Host "Web game generated at: $target"
Write-Host 'Copy drone-rush.html and games/drone-rush/ into the existing website repository.'
